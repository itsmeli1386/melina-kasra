from django.urls import path
from . import views
urlpatterns = [
    path('', view=views.Home, name='home'),
    path('signup/', view=views.signup_view, name='signup'),
]