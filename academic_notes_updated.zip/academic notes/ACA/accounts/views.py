from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from .forms import SignUpForm, CourseForm, NoteForm
from .models import Course, Note


@login_required
def home(request):
    query = request.GET.get("q", "").strip()
    courses = Course.objects.filter(owner=request.user).prefetch_related("notes")
    unassigned_notes = Note.objects.filter(owner=request.user, course__isnull=True)

    if query:
        courses = courses.filter(
            Q(title__icontains=query) |
            Q(notes__title__icontains=query) |
            Q(notes__content__icontains=query)
        ).distinct()
        unassigned_notes = unassigned_notes.filter(
            Q(title__icontains=query) | Q(content__icontains=query)
        )

    for course in courses:
        if query:
            course.filtered_notes = course.notes.filter(
                Q(title__icontains=query) | Q(content__icontains=query)
            )
            if not course.filtered_notes.exists() and query.lower() in course.title.lower():
                course.filtered_notes = course.notes.all()
        else:
            course.filtered_notes = course.notes.all()

    return render(request, "home.html", {
        "courses": courses,
        "unassigned_notes": unassigned_notes,
        "query": query,
    })


def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = SignUpForm()

    return render(request, 'registration/signup.html', {'form': form})


@login_required
def course_add(request):
    if request.method == "POST":
        form = CourseForm(request.POST)
        if form.is_valid():
            course = form.save(commit=False)
            course.owner = request.user
            course.save()
            return redirect("home")
    else:
        form = CourseForm()
    return render(request, "course_form.html", {"form": form})


@login_required
def note_add(request, course_id):
    course = get_object_or_404(Course, id=course_id, owner=request.user)
    if request.method == "POST":
        form = NoteForm(request.POST, request.FILES)
        if form.is_valid():
            note = form.save(commit=False)
            note.owner = request.user
            note.course = course
            note.save()
            return redirect("home")
    else:
        form = NoteForm()
    return render(request, "note_form.html", {"form": form, "course": course})


@login_required
def note_edit(request, note_id):
    note = get_object_or_404(Note, id=note_id, owner=request.user)
    if request.method == "POST":
        form = NoteForm(request.POST, request.FILES, instance=note)
        if form.is_valid():
            form.save()
            return redirect("home")
    else:
        form = NoteForm(instance=note)
    return render(request, "note_form.html", {"form": form, "course": note.course})


@login_required
def note_delete(request, note_id):
    note = get_object_or_404(Note, id=note_id, owner=request.user)
    if request.method == "POST":
        note.delete()
        return redirect("home")
    return render(request, "note_confirm_delete.html", {"note": note})


@login_required
def course_delete(request, course_id):
    course = get_object_or_404(Course, id=course_id, owner=request.user)
    if request.method == "POST":
        course.delete()
        return redirect("home")
    return render(request, "course_confirm_delete.html", {"course": course})
