from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Course, Note

User = get_user_model()


class ModelTests(TestCase):
    """Tests for the Course and Note models."""

    def setUp(self):
        self.user = User.objects.create_user(username="alice", password="pass12345")

    def test_course_str_returns_title(self):
        course = Course.objects.create(owner=self.user, title="Math 101")
        self.assertEqual(str(course), "Math 101")

    def test_note_str_returns_title(self):
        note = Note.objects.create(owner=self.user, title="Chapter 1 summary")
        self.assertEqual(str(note), "Chapter 1 summary")

    def test_note_can_exist_without_course(self):
        note = Note.objects.create(owner=self.user, title="Loose note")
        self.assertIsNone(note.course)


class SignupTests(TestCase):
    """Tests for account creation."""

    def test_signup_creates_user_and_redirects_to_login(self):
        response = self.client.post(reverse("signup"), {
            "email": "bob@example.com",
            "username": "bob",
            "password1": "SuperSecret123",
            "password2": "SuperSecret123",
        })
        self.assertRedirects(response, reverse("login"))
        self.assertTrue(User.objects.filter(username="bob").exists())

    def test_signup_fails_with_mismatched_passwords(self):
        response = self.client.post(reverse("signup"), {
            "email": "bob@example.com",
            "username": "bob",
            "password1": "SuperSecret123",
            "password2": "DifferentPass",
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(User.objects.filter(username="bob").exists())


class LoginRequiredTests(TestCase):
    """Pages that manage data must not be reachable while logged out."""

    def test_home_redirects_anonymous_user_to_login(self):
        response = self.client.get(reverse("home"))
        self.assertEqual(response.status_code, 302)
        self.assertIn("/accounts/login/", response.url)

    def test_course_add_redirects_anonymous_user_to_login(self):
        response = self.client.get(reverse("course_add"))
        self.assertEqual(response.status_code, 302)


class CourseAndNoteFlowTests(TestCase):
    """End-to-end tests for creating, editing and deleting courses/notes."""

    def setUp(self):
        self.user = User.objects.create_user(username="alice", password="pass12345")
        self.other_user = User.objects.create_user(username="mallory", password="pass12345")
        self.client.login(username="alice", password="pass12345")

    def test_course_add_creates_course_owned_by_current_user(self):
        response = self.client.post(reverse("course_add"), {"title": "Physics"})
        self.assertRedirects(response, reverse("home"))
        course = Course.objects.get(title="Physics")
        self.assertEqual(course.owner, self.user)

    def test_note_add_creates_note_linked_to_course_and_owner(self):
        course = Course.objects.create(owner=self.user, title="Chemistry")
        response = self.client.post(
            reverse("note_add", args=[course.id]),
            {"title": "Reactions", "content": "Some notes"},
        )
        self.assertRedirects(response, reverse("home"))
        note = Note.objects.get(title="Reactions")
        self.assertEqual(note.owner, self.user)
        self.assertEqual(note.course, course)

    def test_user_cannot_add_note_to_another_users_course(self):
        foreign_course = Course.objects.create(owner=self.other_user, title="Not yours")
        response = self.client.post(
            reverse("note_add", args=[foreign_course.id]),
            {"title": "Should fail", "content": "..."},
        )
        self.assertEqual(response.status_code, 404)

    def test_note_edit_updates_existing_note(self):
        note = Note.objects.create(owner=self.user, title="Old title")
        response = self.client.post(
            reverse("note_edit", args=[note.id]),
            {"title": "New title", "content": ""},
        )
        self.assertRedirects(response, reverse("home"))
        note.refresh_from_db()
        self.assertEqual(note.title, "New title")

    def test_note_delete_removes_note_on_post(self):
        note = Note.objects.create(owner=self.user, title="To delete")
        response = self.client.post(reverse("note_delete", args=[note.id]))
        self.assertRedirects(response, reverse("home"))
        self.assertFalse(Note.objects.filter(id=note.id).exists())

    def test_course_delete_removes_course_on_post(self):
        course = Course.objects.create(owner=self.user, title="To delete")
        response = self.client.post(reverse("course_delete", args=[course.id]))
        self.assertRedirects(response, reverse("home"))
        self.assertFalse(Course.objects.filter(id=course.id).exists())

    def test_home_search_filters_by_query(self):
        Course.objects.create(owner=self.user, title="Biology")
        Course.objects.create(owner=self.user, title="History")
        response = self.client.get(reverse("home"), {"q": "Bio"})
        self.assertContains(response, "Biology")
        self.assertNotContains(response, "History")
