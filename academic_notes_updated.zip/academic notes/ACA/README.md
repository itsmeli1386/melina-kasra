# Academic Notes (ACA)

A small Django app for keeping courses and notes per user. Each logged-in user
can create courses, add notes (optionally with an attachment) to a course or
keep them unassigned, and search across their own courses/notes.

## Features
- Custom user model (`accounts.User`) with sign up / login / logout
- Courses, each owned by a user
- Notes, optionally linked to a course, optionally with a file attachment
- Search box on the home page (filters courses/notes by title or content)

## Requirements
- Python 3.11+ (project was generated with Django 6.0.5)
- pip

## Setup

Create and activate a virtual environment first (recommended, but the project
will also run without one — see the note below):

```bash
python -m venv venv
source venv/bin/activate      # on Windows: venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Apply database migrations:

```bash
python manage.py migrate
```

(Optional) create an admin user:

```bash
python manage.py createsuperuser
```

Run the development server:

```bash
python manage.py runserver
```

Then open http://127.0.0.1:8000/ in your browser.

## Running tests

```bash
python manage.py test
```

This runs `accounts/tests.py`, which covers:
- model behavior (`Course`, `Note`)
- sign up (success and validation failure)
- that pages requiring login redirect anonymous users
- the full course/note create-edit-delete flow
- that a user can't touch another user's course/notes
- the home page search filter

## About virtual environments (venv)

You don't *have* to use a venv — the project works fine without one, as long
as the `Django` version in `requirements.txt` is installed globally. The venv
is just isolation: it keeps this project's package versions separate from
other Python projects on your machine, so upgrading/removing a package here
never breaks something else. It has no effect on grading or functionality by
itself; it's a best practice, not a requirement.

## About "experiments"

If your friends meant automated **tests** (unit tests, what's in
`accounts/tests.py` now), that's covered above and is worth having regardless
of whether it's required — it proves the CRUD flows and permission checks
actually work.

If they meant something else — e.g. a data-science/notebook-style
"experiments" folder, an A/B testing setup, or a CI pipeline — that's not
something a project like this (a small CRUD web app) normally needs, and it's
not required for the app to function. Ask them what course/assignment
context they mean; if it's a class requirement, it usually refers either to
the automated tests above or to a specific rubric item like "test coverage"
or "CI configuration," not literal experiment scripts.
