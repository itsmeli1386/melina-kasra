from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
from .models import Course, Note

User = get_user_model()


class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('email', 'username', 'password1', 'password2')


class CourseForm(forms.ModelForm):

    class Meta:
        model = Course
        fields = ["title"]


class NoteForm(forms.ModelForm):

    class Meta:
        model = Note
        fields = ["title", "content", "attachment"]
