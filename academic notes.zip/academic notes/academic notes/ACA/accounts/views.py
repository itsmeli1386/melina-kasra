from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from .forms import SignUpForm, CourseForm, NoteForm
from .models import Course, Note


@login_required
def home(request):
    courses = Course.objects.filter(owner=request.user).prefetch_related("notes")
    unassigned_notes = Note.objects.filter(owner=request.user, course__isnull=True)
    return render(request, "home.html", {
        "courses": courses,
        "unassigned_notes": unassigned_notes,
    })


def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = SignUpForm()

    return render(request, 'registration/signup.html', {'form': form})


@login_required
def course_add(request):
    if request.method == "POST":
        form = CourseForm(request.POST)
        if form.is_valid():
            course = form.save(commit=False)
            course.owner = request.user
            course.save()
            return redirect("home")
    else:
        form = CourseForm()
    return render(request, "course_form.html", {"form": form})


@login_required
def note_add(request, course_id):
    course = get_object_or_404(Course, id=course_id, owner=request.user)
    if request.method == "POST":
        form = NoteForm(request.POST, request.FILES)
        if form.is_valid():
            note = form.save(commit=False)
            note.owner = request.user
            note.course = course
            note.save()
            return redirect("home")
    else:
        form = NoteForm()
    return render(request, "note_form.html", {"form": form, "course": course})


@login_required
def note_edit(request, note_id):
    note = get_object_or_404(Note, id=note_id, owner=request.user)
    if request.method == "POST":
        form = NoteForm(request.POST, request.FILES, instance=note)
        if form.is_valid():
            form.save()
            return redirect("home")
    else:
        form = NoteForm(instance=note)
    return render(request, "note_form.html", {"form": form, "course": note.course})


@login_required
@require_POST
def note_delete(request, note_id):
    note = get_object_or_404(Note, id=note_id, owner=request.user)
    note.delete()
    return redirect("home")
