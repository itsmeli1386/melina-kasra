from django.urls import path
from . import views
urlpatterns = [
    path('', view=views.home, name='home'),
    path('signup/', view=views.signup_view, name='signup'),
    path('courses/add/', views.course_add, name='course_add'),
    path('courses/<int:course_id>/notes/add/', views.note_add, name='note_add'),
    path('notes/<int:note_id>/edit/', views.note_edit, name='note_edit'),
    path('notes/<int:note_id>/delete/', views.note_delete, name='note_delete'),
]